#pragma once

//typedef struct _PlatformInfo {
//
//} PlatformInfo;

int getPlatforms();