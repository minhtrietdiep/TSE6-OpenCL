#include <GL/gl.h>
GLuint init_gl(int tex_width, int tex_height);
void draw_quad();